const { getLocaleDateTimeFormat } = require('@angular/common')
const mongoose = require('mongoose')
const Schema = mongoose.Schema
const userSchema = new Schema({
    state: String,
    pickupdate: Date,
    dropdate: Date,
    pickuptime: Date,
    droptime: Date,
    Firstname: String,
    Lastname: String,
    Phone: String,
    email: String
})
module.exports = mongoose.model('user1',userSchema,'users')
