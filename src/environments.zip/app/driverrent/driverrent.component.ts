import { Component, OnInit } from '@angular/core';
import { AmazingTimePickerService } from 'amazing-time-picker';

@Component({
  selector: 'app-driverrent',
  templateUrl: './driverrent.component.html',
  styleUrls: ['./driverrent.component.css']
})
export class DriverrentComponent implements OnInit {

  constructor(private apt: AmazingTimePickerService) { }

  ngOnInit(): void {
  }
  // tslint:disable-next-line: typedef
  open(){
    const amazingTimePicker = this.apt.open();
    amazingTimePicker.afterClose().subscribe(time => {
      console.log(time);
    });
  }

}
