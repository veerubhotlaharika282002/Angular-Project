import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carsearch',
  templateUrl: './carsearch.component.html',
  styleUrls: ['./carsearch.component.css']
})
export class CarsearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
