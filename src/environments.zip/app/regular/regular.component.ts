import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-regular',
  templateUrl: './regular.component.html',
  styleUrls: ['./regular.component.css']
})
export class RegularComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
